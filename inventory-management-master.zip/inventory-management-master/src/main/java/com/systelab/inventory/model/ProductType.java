package com.systelab.inventory.model;

public enum ProductType {
    R, C, Q, K, L, M, N;
}