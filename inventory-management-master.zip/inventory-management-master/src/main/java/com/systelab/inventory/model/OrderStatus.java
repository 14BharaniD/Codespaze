package com.systelab.inventory.model;

public enum OrderStatus {
    pending, cancelled, finalized
}
