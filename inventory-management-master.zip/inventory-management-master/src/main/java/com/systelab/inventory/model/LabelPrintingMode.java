package com.systelab.inventory.model;

public enum LabelPrintingMode {
    LABEL_PER_ENTRY, LABEL_PER_PURCHASE_UNIT, LABEL_PER_CONSUMPTION_UNIT;
}