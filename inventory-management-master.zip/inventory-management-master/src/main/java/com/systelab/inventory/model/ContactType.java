package com.systelab.inventory.model;

public enum ContactType {
    sales, administration, technical
}