package com.systelab.inventory.model;

public enum OrderReceptionStatus {
    pending, partial, full
}