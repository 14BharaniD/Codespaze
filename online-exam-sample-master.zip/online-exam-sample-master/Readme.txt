Maven 3.3.3 project.
Java 8 required.
Environment: Linux Mint 17 (Ubuntu)
Build: mvn clean install
Tests: mvn clean test
Run  : mvn spring-boot:run
Default port: 9000
Database: In-memory H2 database
Scripts: /src/main/resources/*.sql
Spring settings: /src/main/resources/*.properties
Accounts: admin/admin or Ann/Boe or see data.sql in scripts
